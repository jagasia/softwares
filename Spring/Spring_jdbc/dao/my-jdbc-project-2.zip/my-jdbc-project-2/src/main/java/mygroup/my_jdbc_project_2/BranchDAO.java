package mygroup.my_jdbc_project_2;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component("bdao")
public class BranchDAO {
	@Autowired
	private JdbcTemplate jt;
	
	public JdbcTemplate getJt() {
		return jt;
	}
	
	public void setJt(JdbcTemplate jt) {
		this.jt = jt;
	}

	//create
	public void create(Branch branch)
	{
		String sql = "INSERT INTO branch VALUES(?,?,?)";
		jt.update(sql,branch.getBid(),branch.getBname(),branch.getBcity());
	}
	//read
	public Branch read(String bid)
	{
		Branch branch=null;
		branch=jt.queryForObject("SELECT * FROM branch WHERE bid=?",new BranchRowMapper(), bid);
		return branch;
	}
	//update
	public void update(Branch branch)
	{
		String sql="UPDATE branch SET bname=?, bcity=? WHERE bid=?";
		jt.update(sql,branch.getBname(),branch.getBcity(), branch.getBid());
	}
	//delete
	public void delete(String bid)
	{
		String sql="DELETE FROM branch WHERE bid=?";
		jt.update(sql,bid);
	}
	
	//get all branches
	public List<Branch> retrieveAllBranches()
	{
		String sql="SELECT * FROM branch";
		return jt.query(sql, new BranchRowMapper());
	}
	
	//get branches from a city
	public List<Branch> retrieveBranchesByCity(String bcity)
	{
		String sql="SELECT * FROM branch WHERE bcity=?";
		return jt.query(sql,new BranchRowMapper(),bcity);
	}
}
